# BubbleFish(Android Game)

---
## Using Tech:

* Java
* Xml
---
#### Watch Demo : https://www.youtube.com/watch?v=ikz_wVz82xw
---
## Features

*	After opening game splash screen will appear first
*	Move around the fish to eat bubble
*	Eat yellow bubble for 10 points and green for 20 points
*	User have 3 life & each life will be destroy if eat red bubble
*	All score and life are shown upper
*	After game over user can see total score and can start the game again

---


## Author Info
- Linkedin- [@Mohaiminur](https://www.linkedin.com/in/mohaiminur/)
- Youtube- [@Mohaiminur](https://www.youtube.com/channel/UC5MlwVt5vXtpHvgDHxbgqmw)
- Facebook- [@Mohaiminur](https://facebook.com/sifat404)
- Twitter - [@Mohaiminur](https://twitter.com/sifatkhan442)
- Website - [Mohaiminur](https://mohaiminur.ml)

---
## License
<details>
    <summary>
        click to reveal License
    </summary>
    
    The MIT License (MIT)
    
    Copyright (c) 2016 Tan Jun Rong
    
    Permission is hereby granted, free of charge, to any person obtaining a copy
    of this software and associated documentation files (the "Software"), to deal
    in the Software without restriction, including without limitation the rights
    to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
    copies of the Software, and to permit persons to whom the Software is
    furnished to do so, subject to the following conditions:
    
    The above copyright notice and this permission notice shall be included in all
    copies or substantial portions of the Software.
    
    THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
    IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
    FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
    AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
    LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
    OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
    SOFTWARE.


</details>
